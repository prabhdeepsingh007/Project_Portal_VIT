<?php
include 'function.php';
include 'database.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Login</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
    <script src="<?php echo base_url(); ?>/assets/js/admin_login.js"></script>
    <style type="text/css">
      body {
        background-color: #2e2b2b;
      }

    </style>
</head>
<body style="background-color: black;">
<div class="container">
    <div class="row">
      <div class="col-sm-3">
        
      </div>
    <div class="col-sm-6 form_login">
      <form class="newajaxForm" method="post" action="data.php">
        <div class="row">
          <h2 style="text-align: center; color: #ffffff; background-color: #332f2f;    box-shadow: 1px 0px 3px 0px;">Welcome Student</h2>
        </div><br>
        <div class="row">
          <div class="col-sm-6">
            <label>Enter Name</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" placeholder="Enter Name" name="name" required>
        </div>
        </div><br>
        <div class="row">
          <div class="col-sm-6">
            <label>Enter Registration Number</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" placeholder="Enter Registration Number" name="reg" required>
        </div>
        </div><br>
        <div class="row">
          <div class="col-sm-6">
            <label>Enter Password</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" name="password" placeholder="Enter Password" required title="Only characters allowed">
            </div>
        </div><br>
          <div class="row">
          <div class="col-sm-6">
            <label>Date of Birth</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" placeholder="Enter dob" name="dob" required>
        </div>
        </div><br>
          <div class="row">
          <div class="col-sm-6">
            <label>Contact Number</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" placeholder="Enter Number" name="number" required>
        </div>
        </div><br>
 
        <div class="row">
          <div class="col-sm-3">
              
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="submit" name="register">
        </div>
        </div>
      </form>
    </div>
  </div>
</div>
  
</div>

</body> 
</html>