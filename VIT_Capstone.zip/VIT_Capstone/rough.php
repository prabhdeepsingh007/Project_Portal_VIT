<?php
if(isset($_POST["sub4"]))
{
	if(!empty($_FILES['uploade']['tmp_name']) && file_exists($_FILES['uploade']['tmp_name']))
	 {
     $f= addslashes(file_get_contents($_FILES['uploade']['tmp_name']));
      $name = $_FILES["uploade"]["name"];   
     $type = $_FILES["uploade"]["type"];
	 }
	 else
	 	echo"empty";


	 $u1=$_SESSION["user"];
	 $p1=$_SESSION["pass"];
      
     $w="SELECT * FROM $t WHERE username='$u1'";
     $res1 = mysqli_query($conn, $w);
     $f1= mysqli_fetch_assoc($res1);

	if($t=="Task1")
	{
	if(!empty($f1['edate']))
	{   
        $sqlu="UPDATE task1 SET task1='$f',name='$name',type='$type' WHERE username='$u1'";
        if($conn->query($sqlu)===TRUE)
    	{
    		$c=$c+1;
      	echo "<script> alert('Uploaded Sucessfully');
	    window.location.href='http://localhost/Website/php/upload.php';
	    </script>";
    	}
    	else
      	echo"error";
     }
     else
     echo"This task is not assigned till now"; 
      
	}

	else if($t=="Task2")
	{
		if(!empty($f1['edate']))
		{
			$c=$c+1;
		 $sqlu="UPDATE task2 SET task2='$f',name='$name',type='$type' WHERE username='$u1'";
        if($conn->query($sqlu)===TRUE)
    	{
      	echo "<script> alert('Uploaded Sucessfully');
	    window.location.href='http://localhost/Website/php/upload.php';
	    </script>";
    	}
    	else
      	echo"error";
	}     
	else
	echo"This task is not assigned till now"; 
	}
	else if($t=="Task3")
	{
		if(!empty($f1['edate']))
		{
			$c=$c+1;
		 $sqlu="UPDATE task3 SET task3='$f',name='$name',type='$type' WHERE username='$u1'";
        if($conn->query($sqlu)===TRUE)
    	{
      	echo "<script> alert('Uploaded Sucessfully');
	    window.location.href='http://localhost/Website/php/upload.php';
	    </script>";
    	}
    	else
      	echo"error";
     }
     else
     echo"This task is not assigned till now"; 
	}
	else if($t=="Task4")
	{
		if(!empty($f1['edate']))
		{
			$c=$c+1;
		 $sqlu="UPDATE task4 SET task4='$f',name='$name',type='$type' WHERE username='$u1'";
        if($conn->query($sqlu)===TRUE)
    	{
      	echo "<script> alert('Uploaded Sucessfully');
	    window.location.href='http://localhost/Website/php/upload.php';
	    </script>";
    	}
    	else
      	echo"error";
     }
     else
     echo"This task is not assigned till now"; 
	}
	else if($t=="Task5")
	{
		if(!empty($f1['edate']))
		{
			$c=$c+1;
		 $sqlu="UPDATE task5 SET task5='$f',name='$name',type='$type' WHERE username='$u1'";
        if($conn->query($sqlu)===TRUE)
    	{
      	echo "<script> alert('Uploaded Sucessfully');
	    window.location.href='http://localhost/Website/php/upload.php';
	    </script>";
    	}
    	else
      	echo"error";
	}     }
	else
	echo"This task is not assigned till now"; 
}
?>