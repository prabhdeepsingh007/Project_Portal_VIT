<?php
include 'function1.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/faculty_login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>Welcome Faculty</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
		.sidepanel  {
  width: 0;
  position: fixed;
  z-index: 1;
  height: 400px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" style="background-color: black; z-index: 999;">
			<div class="col-sm-2">
				<button class="openbtn" onclick="openNav()">☰</button>
				<div id="mySidepanel" class="sidepanel">
	  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
					<a href="project_approval.php" style="margin-top: 30px;">Project Approval</a>
					<a href="view_fac_document.php">View Document</a>
					<a href="marks_enter_review_select.php">Enter Marks And Remarks</a>
					<a href="reg_status.php">Registration Status</a>
					<a href="reset_fac_password.php">Reset Password</a>
				</div>

				<script>
				function openNav() {
				  document.getElementById("mySidepanel").style.width = "250px";
				}

				function closeNav() {
				  document.getElementById("mySidepanel").style.width = "0";
				}
				</script> 
			</div>
			<div class="col-sm-8">
				<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['fid']; ?></h1>
			</div>
			<div class="col-sm-2">
				<div style="float: right;">
					<form method="post">
						<input type="submit" name="logout" value="logout" style="margin: 20px;">
					</form>			
				</div>
			</div>
		</div>
	</div>
	<br><br>
	
					<?php
						$y_test=$_POST['review'];
						$y_test=strtolower($y_test);
					    $sq_test = "SELECT name FROM faculty_login WHERE fac_id = '".$_SESSION['fid']."' ";
						$result = $db-> query($sq_test);
						$row = $result->fetch_assoc();
						$fac_tb=$row['name'];
    					$fac_tb=strtolower($fac_tb);
						$fac_tb=str_replace(' ','',$fac_tb);


						$sq_test1 = "SELECT stud1,stud2,stud3 FROM $fac_tb";
						$result1 = $db-> query($sq_test1);
						
						if($y_test=='review1')
						{
							if($result1->num_rows > 0) 
	                		{

	                			$catnum =1;
	                			while($row1 = $result1->fetch_assoc())
	                			{

	                			if($row1['stud1']!=" ")
	                			{
	                				$x=$row1["stud1"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Title Marks</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["review1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["remark1"]; ?>" style="width: 96%;"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				          <?php 
								}

								if($row1['stud2']!=" ")
	                			{
	                				$x=$row1["stud2"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
											
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Title Marks</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["review1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["remark1"]; ?>" style="width: 96%;"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}

								if($row1['stud3']!=" ")
	                			{
	                				$x=$row1["stud3"];


	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Title Marks</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["review1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["remark1"]; ?>" style="width: 96%;"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}
							}
							}
							}
							?>
</table>
			</div>

		</div>

	</div>
		
	</div>

	<?php
						$y_test1=$_POST['review'];
						$y_test1=strtolower($y_test1);
					    $sq_test = "SELECT name FROM faculty_login WHERE fac_id = '".$_SESSION['fid']."' ";
						$result = $db-> query($sq_test);
						$row = $result->fetch_assoc();
						$fac_tb=$row['name'];
    					$fac_tb=strtolower($fac_tb);
						$fac_tb=str_replace(' ','',$fac_tb);


						$sq_test1 = "SELECT stud1,stud2,stud3 FROM $fac_tb";
						$result1 = $db-> query($sq_test1);
						
						if($y_test1=='review2')
						{
							if($result1->num_rows > 0) 
	                		{

	                			$catnum =1;
	                			while($row1 = $result1->fetch_assoc())
	                			{

	                			if($row1['stud1']!=" ")
	                			{
	                				$x=$row1["stud1"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Problem Formulation And Proposed Methodology(10)</th>
													    <th>Challenging Issues Considered And Addressed(10)</th>
													    <th>Implementation(10)</th>
													    <th>Comperative Result Analysis(10)</th>
													    <th>Total(Out of 40)</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks2.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value ="<?php echo $ro1["c"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value ="<?php echo $ro1["review2"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark2"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}

								if($row1['stud2']!=" ")
	                			{
	                				$x=$row1["stud2"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Problem Formulation And Proposed Methodology(10)</th>
													    <th>Challenging Issues Considered And Addressed(10)</th>
													    <th>Implementation(10)</th>
													    <th>Comperative Result Analysis(10)</th>
													    <th>Total(Out of 40)</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks2.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value ="<?php echo $ro1["c"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value ="<?php echo $ro1["review2"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark2"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}

								if($row1['stud3']!=" ")
	                			{
	                				$x=$row1["stud3"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>Problem Formulation And Proposed Methodology(10)</th>
													    <th>Challenging Issues Considered And Addressed(10)</th>
													    <th>Implementation(10)</th>
													    <th>Comperative Result Analysis(10)</th>
													    <th>Total(Out of 40)</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks2.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value ="<?php echo $ro1["c"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value ="<?php echo $ro1["review2"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark2"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
			                              
			                                
		                                </form>



		                             </tr>

				 <?php 
								}
							}
							}
							}
							?>
</table>
			</div>

		</div>


	</div>
		
	</div>

	<?php
						$y_test2=$_POST['review'];
						$y_test2=strtolower($y_test2);
					    $sq_test = "SELECT name FROM faculty_login WHERE fac_id = '".$_SESSION['fid']."' ";
						$result = $db-> query($sq_test);
						$row = $result->fetch_assoc();
						$fac_tb=$row['name'];
    					$fac_tb=strtolower($fac_tb);
						$fac_tb=str_replace(' ','',$fac_tb);


						$sq_test1 = "SELECT stud1,stud2,stud3 FROM $fac_tb";
						$result1 = $db-> query($sq_test1);
						
						if($y_test2=='review3')
						{
							if($result1->num_rows > 0) 
	                		{

	                			$catnum =1;
	                			while($row1 = $result1->fetch_assoc())
	                			{

	                			if($row1['stud1']!=" ")
	                			{
	                				$x=$row1["stud1"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<tr>
													    
													    <th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>A</th>
													    <th>B</th>
													    <th>C</th>
													    <th>D</th>
													    <th>Total</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks3.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value="<?php echo $ro1["c1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value="<?php echo $ro1["review3"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark3"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}

								if($row1['stud2']!=" ")
	                			{
	                				$x=$row1["stud2"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>A</th>
													    <th>B</th>
													    <th>C</th>
													    <th>D</th>
													    <th>Total</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks3.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value="<?php echo $ro1["c1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value="<?php echo $ro1["review3"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark3"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}

								if($row1['stud3']!=" ")
	                			{
	                				$x=$row1["stud3"];

	                				$sqll="SELECT * FROM marks WHERE reg='$x'";
									$res1 = $db->query($sqll);
									$ro1 = $res1->fetch_assoc();
									
		                		    ?>
		                             <div class="container-fluid">
									<div class="row">
										<div class="col-sm-1">
											
										</div>

										<div class="col-sm-9">
											<div>
												
												<table class="table table-striped table-bordered" style="height: 17px;">
													<th>S.NO</th>
													    <th>Reg No.</th> 
													    <th>A</th>
													    <th>B</th>
													    <th>C</th>
													    <th>D</th>
													    <th>Total</th>
													    <th>Expert's Remarks/Comments</th>
													    <th>Update</th>
													</tr>
		                             <tr>
		                             	<td><?php echo $catnum; $catnum++; ?></td>
		                             	<td><?php echo $x; ?></td>
		                             	<form action="<?php echo base_url(); ?>/marks3.php?reg=<?php echo $x; ?>" method="POST">
			                                <td><input type="text" name="r1" value="<?php echo $ro1["a1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r2" value ="<?php echo $ro1["b1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r3" value="<?php echo $ro1["c1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r4" value ="<?php echo $ro1["d1"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r5" value="<?php echo $ro1["review3"]; ?>" style="width: 60px;"></td>
			                                <td><input type="text" name="r6" value ="<?php echo $ro1["remark3"]; ?>" style="width: 200px"></td>
			                                <td><input type="submit" name="submit" value="Update"></td>
		                                </form>



		                             </tr>

				 <?php 
								}
							}
							}
							}
							?>
</table>
			</div>

		</div>


	</div>
		
	</div>