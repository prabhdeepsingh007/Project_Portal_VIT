<?php
include 'function2.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/hod_login.php");
}
?>



<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>HOD</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
.sidepanel{
  width: 0;
  position: fixed;
  z-index: 1;
  height: 450px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}

td {
	width: 33%;
	padding: 0 5%;
}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="row" style="background-color: black; z-index: 999;">
		<div class="col-sm-2">
			<button class="openbtn" onclick="openNav()">☰</button>
			<div id="mySidepanel" class="sidepanel">
  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
				<a href="view_hod_faculty.php" style="margin-top: 30px;">View All Faculty</a>
				<a href="view_hod_student.php">View All Students</a>
				<a href="view_hod_studfac.php">View Students under Faculty</a>
				<a href="view_hod_markdoc.php">View Students Marks</a>
				<a href="view_hod_document.php">View Uploaded Documents</a>
				<a href="hod_schedule.php">Scheduling</a>
				<a href="view_panel.php">View Panel</a>
				<a href="reset_fac_password.php">Reset Password</a>
			</div>

			<script>
			function openNav() {
			  document.getElementById("mySidepanel").style.width = "250px";
			}

			function closeNav() {
			  document.getElementById("mySidepanel").style.width = "0";
			}
			</script> 
		</div>
		<div class="col-sm-8">
			<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['hid']; ?></h1>
		</div>
		<div class="col-sm-2">
			<div style="float: right;">
				<form method="post">
					<input type="submit" name="logout" value="logout" style="margin: 20px;">
				</form>			
			</div>
		</div>
	</div>
</div>
<br>
<br>
<div class="container">
	<div class="row">
		<div class="col-sm-10 col-sm-offset-1">
			<div class="col-sm-12">
				<form class="form-horizontal" action="hod_schedule.php" method="POST">
					<div class="col-sm-6 col-sm-offset-3">
						<button type="submit" class="btn btn-default" name="submit" style="width:100%;">Create Schedule</button>
					</div>
				</form>
			</div>
			<div class="col-sm-12">
				<h2> Unassigned faculty </h2>
				<?php 
	                $sql = "SELECT * FROM faculty_login";
	                $result = $db-> query($sql);
					
					$panels = array();
					
					$rows = $result->num_rows;

					if($rows>0) 
	                {
	                // output data of each row
	                	
						$catnum =0;
						$total_panels = floor($rows/3)*3;
	                	while($row = $result->fetch_assoc()) {
							
							if( $catnum > $total_panels ) {
								?>
									<tr>
										<td><?php echo $row['name'];?></td>
										<td><?php echo $row['fac_id'];?></td>
										<td><?php echo $row['domain'];?></td>
									</tr>
								<?php
							}

							if($catnum%3==0) {
								$curr_panel = array();
							}
							array_push($curr_panel,$row['name']);
							if($catnum%3==2) {
								array_push($panels,$curr_panel);
							}

							$catnum++;
						
						}

				    $sql = "SELECT * FROM stud_login";
	                $result = $db-> query($sql);
					
					$schedule = array();
					
					$curr_panel = 0;
					foreach($panels as $panel) {
						$schedule[$curr_panel] = array();
						$curr_panel++;
					}
					
	                if($result->num_rows>0) 
	                {
						$catnum = 0;
						$len = count($panels);
	                	while($row = $result->fetch_assoc()) {
							if($catnum >= $len)
								$catnum = 0;
							array_push( $schedule[$catnum], $row['reg']);
							$catnum++;
						}
					}
					
					foreach( $schedule as $panel_number => $students ) {

						?>
						<h2 style="margin-top: 20px;"> Panel <?php echo $panel_number; ?> </h2>
						<div class="col-md-12">
							<table class="col-md-6" >
							<tr>
								<?php 
									foreach( $panels[$panel_number] as $faculty ) {
										// echo "hello";
										?>
											<td> <h4> <?php echo $faculty; ?> </h4> </td>
										<?php									
									}
								?>
							</tr>

							<?php 
								foreach($students as $student) {
									?>
										<tr> <td> <?php echo $student; ?> </td> </tr>
									<?php 
								}
							?>

							</table>
						</div>
						<?php
						
					}

						// $curr_panel = 1;
						// foreach ($panels as $panel) {
						 	
								// print_r($panel);
								// $curr_panel++;
						// }
						// print_r( $panels);
					} 
				?>
			</div>
		</div>
	</div>
</div>
<!-- <div class="container-fluid">
	<div class="row">
		<div class="col-sm-1">
			
		</div>
		<div class="col-sm-10">
			<div class="col-sm-12" style="background-color:#ffefef;border-top: 1px solid blue;">
			<div >
				<h2>Domain Selection</h2>
				<hr style="border-top: 1px solid black;width: 100%;">

				<form class="form-horizontal" action="faculty_schedule.php" method="POST">
    				<div class="form-group">
      				<label>Domain</label>
                    	<select class="form-control" name="domain" style="width: 85%;margin-left: 68px;margin-right: 61px;margin-top: -32px;">
                        	<option>Image Processing</option>
						    <option>Machine Learning</option>
						    <option>Artificial Intelligence</option>
						    <option>Data Minning</option>
                      </select>
    				</div>

    				<div class="form-group">    
    					<div class="col-sm-4">
    						
    					</div>    
      					<div class="col-sm-3">
        					<button type="submit" class="btn btn-default" name="submit" style="width:100%;">View</button>
      					</div>

    				</div>
  				</form>
			</div>
		</div>
	</div>

		<div class="col-sm-1">
				
		</div>
   </div>	 -->
</div>