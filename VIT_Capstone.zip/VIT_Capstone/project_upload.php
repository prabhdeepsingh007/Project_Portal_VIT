<?php
include 'function.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/stud_login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>Welcome Student</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
		.sidepanel  {
		  width: 0;
		  position: fixed;
		  z-index: 1;
		  height: 320px;
		  top: 66px;
		  left: 0;
		  background-color: #111;
		  overflow-x: hidden;
		  transition: 0.5s;
		  padding-top: 60px;
		}

		.sidepanel a {
		  padding: 8px 8px 8px 32px;
		  text-decoration: none;
		  font-size: 20px;
		  color: #818181;
		  display: block;
		  transition: 0.3s;
		}

		.sidepanel a:hover {
		  color: #f1f1f1;
		}

		.sidepanel .closebtn {
		  position: absolute;
		  top: 0;
		  right: 25px;
		  font-size: 36px;
		}

		.openbtn {
		  font-size: 20px;
		  cursor: pointer;
		  background-color: #111;
		  color: white;
		  padding: 10px 15px;
		  border: none;
		}

		.openbtn:hover {
		  background-color:#444;
		}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" style="background-color: black; z-index: 999;">
			<div class="col-sm-2">
				<button class="openbtn" onclick="openNav()">☰</button>
				<div id="mySidepanel" class="sidepanel">
	  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
					<a href="stud_domain.php" style="margin-top: 30px;">Domain</a>
					<a href="project_upload.php">Project Upload</a>
					<a href="project_details.php">Project Details</a>
					<a href="reset_password.php">Reset Password</a>
				</div>

				<script>
				function openNav() {
				  document.getElementById("mySidepanel").style.width = "200px";
				}

				function closeNav() {
				  document.getElementById("mySidepanel").style.width = "0";
				}
				</script> 
			</div>
			<div class="col-sm-8">
				<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['reg']; ?></h1>
			</div>
			<div class="col-sm-2">
				<div style="float: right;">
					<form method="post">
						<input type="submit" name="logout" value="logout" style="margin: 20px;">
					</form>			
				</div>
			</div>
		</div>
	</div>
<br>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
			
		</div>
		<div class="col-sm-8">
			<p>Note:-.ppt,.pptx format are not supported convert the .ppt,.pptx format to pdf and then upload.</p>
			<table class="table table-striped table-bordered" style="height: 17px;">
				<tr>
				    <th>S.No</th>
				    <th>Review</th>
				    <th>Upload</th>
				    <th>View Document</th>
				    <th>Marks</th>
				    <th>Remarks</th> 
				</tr>
				<?php
				if(isset($_GET['x']))
				 {
			        $t1=$_GET['x'];
			        
			       
			        if($t1=='doc1')
			        {
			       
			        $s="SELECT * FROM upload WHERE reg='".$_SESSION['reg']."'";
			        $res1 = $db-> query($s);
			       	$f = $res1->fetch_assoc();
			        $type=$f["type1"];
			        $name=$f["name1"];
			        $content=$f["doc1"];
				     header("Content-type: $type");
				     header("Content-Disposition: attachment; filename=$name");
				     echo $content;
				     ob_clean();
				     flush();
				   }
				    else if($t1=='doc2')
				    {
				    $s="SELECT * FROM upload WHERE reg='".$_SESSION['reg']."' ";
			        $res1 = $db-> query($s);
			       	$f = $res1->fetch_assoc();
			        $type=$f["type2"];
			        $name=$f["name2"];
			        $content=$f["doc2"];
				     header("Content-type: $type");
				     header("Content-Disposition: attachment; filename=$name");
				     echo $content;
				     ob_clean();
				     flush();
				    }

				     else if($t1=='doc3')
				    {
				      $s="SELECT * FROM upload WHERE reg='".$_SESSION['reg']."'";
			        $res1 = $db-> query($s);
			       	$f = $res1->fetch_assoc();
			        $type=$f["type3"];
			        $name=$f["name3"];
			        $content=$f["doc3"];
				     header("Content-type: $type");
				     header("Content-Disposition: attachment; filename=$name");
				     echo $content;
				     ob_clean();
				     flush();
				    }
				}
				?>
				<?php
				$sq_test = "SELECT * FROM stud_login WHERE reg = '".$_SESSION['reg']."' ";
		    	$result = $db-> query($sq_test);
		    	$row = $result->fetch_assoc();
				$teacher=$row['f_name'];
				$count=$row['count'];
				$upload=$row['upload'];
				$upload1=$row['upload1'];
				$upload2=$row['upload2'];
				$sql = "SELECT review1,review2,review3,remark1,remark2,remark3 FROM marks WHERE reg = '".$_SESSION['reg']."'";
				$result1 = $db-> query($sql);
		    	$row1 = $result1->fetch_assoc();


		    	$y2="SELECT * FROM upload WHERE reg='".$_SESSION['reg']."' ";
		    	$r_y2 = $db-> query($y2);
		    	$data1 = $r_y2->fetch_assoc();

		    	$sq_test = "SELECT * FROM $teacher WHERE stud1 ='".$_SESSION['reg']."' OR stud2='".$_SESSION['reg']."' OR stud3='".$_SESSION['reg']."' ";
				$result = $db-> query($sq_test);
				$row = $result->fetch_assoc();



		    	
		    	
				?>
				<tr>
					<td>1.</td>
					<td>Review 1</td>
					<?php
					if($count==1)
					{
						if($row['status']=='Approved')
						{
					?>
					<td><form action="project_upload.php" method="post" enctype="multipart/form-data">
				    		<input type="file" name="r1"><br>
				    		<button type="submit" class="btn btn-default" name="sub_review1">Submit</button>
						</form>
					</td>
					<?php
						}
						else
						{
							?>
							<td>Title Not Approved</td>
							<?php
						}

					?>
					
						
					
					<?php
					}
					else
					{
					?>
					<td>Not registered yet</td>
					<?php
				}
					?>
					<?php
						if($count==1 && $upload==1)
						{
						?>
						<td><a href="<?php echo base_url(); ?>/project_upload.php?x=doc1"><?php echo $data1['name1']?></a></td>
						<?php
						}
						else
						{
						?>
						<td>Document not uploded</td>
						<?php
						}
						?>
					<td><?php echo $row1['review1'];?></td>
					<td><?php echo $row1['remark1'];?></td>
				</tr>

				<?php


				?>
				<tr>
					<td>2.</td>
					<td>Review 2</td>
					<?php
					if($count==1)
					{
						if($row['status']=='Approved')
						{
					?>
					<td><form action="project_upload.php" method="post" enctype="multipart/form-data">
				    	<input type="file" name="r2"><br>
				    	<button type="submit" class="btn btn-default" name="sub_review2">Submit</button>
					</form></td>

					<?php
						}
						else
						{
							?>
							<td>Title Not Approved</td>
							<?php
						}

					?>
					
						
					
					<?php
					}
					else
					{
					?>
					<td>Not registered yet</td>
					<?php
					}
					?>
					<?php
						if($count==1 && $upload1==1)
						{
						?>
						<td><a href="<?php echo base_url(); ?>/project_upload.php?x=doc2"><?php echo $data1['name2']?></a></td>
						<?php
						}
						else
						{
						?>
						<td>Document not uploded</td>
						<?php
						}
						?>
					<td><?php echo $row1['review2'];?></td>
					<td><?php echo $row1['remark2'];?></td>
				</tr>
				<?php


				?>
				<tr>
					<td>3.</td>
					<td>Review 3</td>
					<?php
					if($count==1)
					{
						if($row['status']=='Approved')
						{
					?>
					<td><form action="project_upload.php" method="post" enctype="multipart/form-data">
				    	<input type="file" name="r3"><br>
				    	<button type="submit" class="btn btn-default" name="sub_review3">Submit</button>
					</form></td>
					
					<?php
						}
						else
						{
							?>
							<td>Title Not Approved</td>
							<?php
						}

					?>	
					
					<?php
					}
					else
					{
					?>
					<td>Not registered yet</td>
					<?php
					}

					?>

					<?php
						if($count==1 && $upload2==1)
						{
						?>
						<td><a href="<?php echo base_url(); ?>/project_upload.php?x=doc3"><?php echo $data1['name3']?></a></td>

						<?php
						}
						else
						{
						?>
						<td>Document not uploded</td>
						<?php
						}
						?>
					<td><?php echo $row1['review3'];?></td>
					<td><?php echo $row1['remark3'];?></td>
				</tr>
				
			</table>
		</div>
		<div class="col-sm-2">
			
		</div>
	</div>
	<?php
	if(isset($_POST['sub_review1']))
	{
		if(!empty($_FILES['r1']['tmp_name']) && file_exists($_FILES['r1']['tmp_name']))
	 	{
     		
     		$f= addslashes(file_get_contents($_FILES['r1']['tmp_name']));
      		$name = $_FILES['r1']['name'];   
     		$type = $_FILES['r1']['type'];


     		
		 }
	 	else
	 		echo "<script> alert('Select a File'); </script>";



	 	$sqlu="UPDATE upload SET doc1='$f',name1='$name',type1='$type' WHERE reg = '".$_SESSION['reg']."'";
	 	$sqlupl = "SELECT * FROM upload WHERE reg = '".$_SESSION['reg']."' ";
		$result_upl = $db-> query($sqlupl);
		$row_upl = $result_upl->fetch_assoc();
		if($row_upl['doc1']!='')
		{
			$sql_upload="UPDATE stud_login SET upload='1' WHERE reg = '".$_SESSION['reg']."'";
		}
		
		
	        if($db->query($sqlu)===TRUE)
	    	{
	    		//echo "Hell0";
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	if($db->query($sql_upload)===TRUE)
	    	{
	    		//echo "Hell0";
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	else
	      	echo "<script> alert('no upload in stud_login'); </script>";

	      

	      
	 	

	}


	if(isset($_POST['sub_review2']))
	{
		if(!empty($_FILES['r2']['tmp_name']) && file_exists($_FILES['r2']['tmp_name']))
	 	{
     		
     		$f1= addslashes(file_get_contents($_FILES['r2']['tmp_name']));
      		$name = $_FILES["r2"]["name"];   
     		$type = $_FILES["r2"]["type"];
     		

     		
		 }
	 	else
	 		echo "<script> alert('Select a File'); </script>";



	 	$sqlu="UPDATE upload SET doc2='$f1',name2='$name',type2='$type' WHERE reg = '".$_SESSION['reg']."'";
	 	$sqlupl = "SELECT * FROM upload WHERE reg = '".$_SESSION['reg']."' ";
		$result_upl = $db-> query($sqlupl);
		$row_upl = $result_upl->fetch_assoc();

		if($row_upl['doc2']!='')
		{
			$sql_upload1="UPDATE stud_login SET upload1='1' WHERE reg = '".$_SESSION['reg']."'";
		}


	        if($db->query($sqlu)===TRUE)
	    	{
	    		
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	else
	      	echo "<script> alert('Size should be less than 5MB'); </script>";

	      if($db->query($sql_upload1)===TRUE)
	    	{
	    		//echo "Hell0";
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	else
	      	echo "<script> alert('no upload in stud_login'); </script>";

	 	

	}


	if(isset($_POST['sub_review3']))
	{
		if(!empty($_FILES['r3']['tmp_name']) && file_exists($_FILES['r3']['tmp_name']))
	 	{
     		
     		$f2= addslashes(file_get_contents($_FILES['r3']['tmp_name']));
      		$name = $_FILES["r3"]["name"];   
     		$type = $_FILES["r3"]["type"];
     		

     		
		 }
	 	else
	 		echo "<script> alert('Select a File'); </script>";



	 	$sqlu="UPDATE upload SET doc3='$f2',name3='$name',type3='$type' WHERE reg = '".$_SESSION['reg']."' ";
	 	$sqlupl = "SELECT * FROM upload WHERE reg = '".$_SESSION['reg']."' ";
		$result_upl = $db-> query($sqlupl);
		$row_upl = $result_upl->fetch_assoc();

		if($row_upl['doc3']!='')
		{
			$sql_upload2="UPDATE stud_login SET upload2='1' WHERE reg = '".$_SESSION['reg']."'";
		}
	 	


	        if($db->query($sqlu)===TRUE)
	    	{
	    		
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	else
	      	echo "<script> alert('Size should be less than 5MB'); </script>";

	      if($db->query($sql_upload2)===TRUE)
	    	{
	    		//echo "Hell0";
	      	echo "<script> alert('Uploaded Sucessfully');
		    window.location.href='http://localhost/VIT_Capstone/project_upload.php';
		    </script>";
	    	}
	    	else
	      	echo "<script> alert('no upload in stud_login'); </script>";


	 	

	}
	?>
</div>




