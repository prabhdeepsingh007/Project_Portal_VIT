<?php
include 'function.php';
include 'database.php';


if(isset($_POST['register']) /*&& preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST['password'])*/)
{
	
	if(empty($_POST["name"]))
		echo "Name is required";
	else
	{
		$name=$_POST["name"];
	}

	if(empty($_POST["reg"]))
		echo "Registration Number is required";
	else
	{
		$fname=$_POST["reg"];
	}

	if(empty($_POST["password"]))
		echo "Password";
	else
		$lname=$_POST["password"];

	if(empty($_POST["dob"]))
		echo "Date of Birth";
	else
		$username=$_POST["dob"];

	if(empty($_POST["number"]))
		echo "Contact number is required";
	else
		$password=$_POST["number"];

	

	


 	$sql = "INSERT INTO graphics(f_id,f_name,stud_alloted,stud_left,f_name1) VALUES ('$name','$fname','$lname','$username','$password')";
 	
 	if($db->query($sql) === TRUE)
	{ 	 
		echo "<script> alert('Registered');
    window.location.href='http://localhost/VIT_Capstone/test.php';
    </script>";
    
	}
	else
	{
	    echo "Error: " . $sql . "<br>" . $db->error;
	}

	
}
