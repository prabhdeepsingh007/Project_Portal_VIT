<?php
include 'function1.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/faculty_login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>Welcome Faculty</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
		.sidepanel  {
  width: 0;
  position: fixed;
  z-index: 1;
  height: 400px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" style="background-color: black; z-index: 999;">
			<div class="col-sm-2">
				<button class="openbtn" onclick="openNav()">☰</button>
				<div id="mySidepanel" class="sidepanel">
	  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
					<a href="project_approval.php" style="margin-top: 30px;">Project Approval</a>
					<a href="view_fac_document.php">View Document</a>
					<a href="marks_enter_review_select.php">Enter Marks And Remarks</a>
					<a href="reg_status.php">Registration Status</a>
					<a href="reset_fac_password.php">Reset Password</a>
				</div>

				<script>
				function openNav() {
				  document.getElementById("mySidepanel").style.width = "250px";
				}

				function closeNav() {
				  document.getElementById("mySidepanel").style.width = "0";
				}
				</script> 
			</div>
			<div class="col-sm-8">
				<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['fid']; ?></h1>
			</div>
			<div class="col-sm-2">
				<div style="float: right;">
					<form method="post">
						<input type="submit" name="logout" value="logout" style="margin: 20px;">
					</form>			
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-2">
				
			</div>

			<div class="col-sm-8">
				<div>
					<br><br>
					<table class="table table-striped table-bordered" style="height: 17px;">
						<tr>
						    
						    <th>S.No</th> 
						    <th>Student1</th>
						    <th>Student2</th> 
						    <th>Student3</th>
						    <th>Title</th> 
						    <th>Status</th>

						</tr>
						
						<tr>
							<?php
								$sq_test = "SELECT name FROM faculty_login WHERE fac_id = '".$_SESSION['fid']."' ";
								$result = $db-> query($sq_test);
								$row = $result->fetch_assoc();
								$fac_tb=$row['name'];
		    					$fac_tb=strtolower($fac_tb);
								$fac_tb=str_replace(' ','',$fac_tb);

								$sq_test1 = "SELECT * FROM $fac_tb ";
								$result1 = $db-> query($sq_test1);
								
								if($result1->num_rows > 0) 
                				{
                // output data of each row
                					$catnum =1;
                					while($row1 = $result1->fetch_assoc()) {
                				?>
								<tr>
							    <td><?php echo $catnum; $catnum++; ?></td>
								<td><?php echo $row1["stud1"];?></td>
								<td><?php echo $row1["stud2"];?></td>
								<td><?php echo $row1["stud3"];?></td>
								<td><?php echo $row1["title"];?></td>
								<?php if($row1['status']=="") 
								{?>
								<td><a href="<?php echo base_url(); ?>/approve_project.php?id=<?php echo $row1["id"]; ?>" class="form-control" style="width: 48%; float: left;">Approve</a>

									<a href="<?php echo base_url(); ?>/reject_project.php?id=<?php echo $row1["id"]; ?>" style="width: 48%; float: left;" class="form-control">Reject</a></td>
									<?php
								}
								else
									{
								?>
									<td><?php echo $row1["status"];?></td>
									<?php } ?>
								</tr>

				
							<?php
						 } }
							?>
					</table>
				</div>

				
					

			
				


			</div>

			<div class="col-sm-2">
				
			</div>
		</div>
		
	</div>