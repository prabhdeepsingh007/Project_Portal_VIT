<?php
/*
*Enter all database detail
*creat conection
*/
$servername = "localhost"; //Enter Server name
$username = "root";		//User name
$password = "";	//Enter password
$dbname = "vit";	//Enter database name

$db = new mysqli($servername, $username, $password, $dbname);

if ($db->connect_error) {
    exit;
} 
?>