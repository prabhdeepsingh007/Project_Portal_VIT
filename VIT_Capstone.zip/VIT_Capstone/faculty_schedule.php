<?php
include 'function2.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/hod_login.php");
}
?>



<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>HOD</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
.sidepanel{
  width: 0;
  position: fixed;
  z-index: 1;
  height: 450px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="row" style="background-color: black; z-index: 999;">
		<div class="col-sm-2">
			<button class="openbtn" onclick="openNav()">☰</button>
			<div id="mySidepanel" class="sidepanel">
  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
				<a href="view_hod_faculty.php" style="margin-top: 30px;">View All Faculty</a>
				<a href="view_hod_student.php">View All Students</a>
				<a href="view_hod_studfac.php">View Students under Faculty</a>
				<a href="view_hod_markdoc.php">View Students Marks</a>
				<a href="view_hod_document.php">View Uploaded Documents</a>
				<a href="hod_schedule.php">Scheduling</a>
				<a href="view_panel.php">View Panel</a>
				<a href="reset_fac_password.php">Reset Password</a>
			</div>

			<script>
			function openNav() {
			  document.getElementById("mySidepanel").style.width = "250px";
			}

			function closeNav() {
			  document.getElementById("mySidepanel").style.width = "0";
			}
			</script> 
		</div>
		<div class="col-sm-8">
			<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['hid']; ?></h1>
		</div>
		<div class="col-sm-2">
			<div style="float: right;">
				<form method="post">
					<input type="submit" name="logout" value="logout" style="margin: 20px;">
				</form>			
			</div>
		</div>
	</div>
</div>
<br>
<br>


<div class="container-fluid">
	<div class="row">
		<?php
			if(isset($_POST['submit']))
			{
				$x=$_POST['domain'];
				$x=strtolower($x);
				$x=str_replace(' ','',$x);
			}
		?>
		<div class="col-sm-2">
			
		</div>

		<div class="col-sm-10">
			<form class="form-horizontal" action="data_schedule.php" method="POST" class="form-group">
				
				<div class="col-sm-12">
					<label>Faculty-1</label>

					<select class="form-control" name="f1" style="width: 85%;margin-left: 68px;margin-right: 61px;margin-top: -32px;">
                    <?php
                		$s="SELECT * FROM faculty_login WHERE domain='$x'";
                		$result = $db-> query($s);
						if($result->num_rows > 0)
						{
						    while($row = $result->fetch_assoc()) 
				    		{
				    			if($row['pa']==0)
				    			{ ?>

				    				<option><?php echo $row['name']?></option>
				    				<?php
				    			}
				    		}
				    	}

                		?>
                      </select>

				</div>
				<br><br><br>
				<div class="col-sm-12">
					<label>Faculty-2</label>
					<select class="form-control" name="f2" style="width: 85%;margin-left: 68px;margin-right: 61px;margin-top: -32px;">
		        		<?php
		        		$s1="SELECT * FROM faculty";
		        		$result1 = $db-> query($s1);
						if($result1->num_rows > 0)
						{
						    while($row1 = $result1->fetch_assoc()) 
				    		{
				    			if($row1['pa']==0)
				    			{ ?>

				    				<option><?php echo $row1['name']?></option>
				    				<?php
				    			}
				    		}
				    	}

		        		?>
          			</select>
				</div>
				<br><br><br>
				<div class="col-sm-12">
					<label>Faculty-3</label>
					<select class="form-control" name="f3" style="width: 85%;margin-left: 68px;margin-right: 61px;margin-top: -32px;">
		        		<?php
		        		$s2="SELECT * FROM faculty";
		        		$result2 = $db-> query($s2);
						if($result2->num_rows > 0)
						{
						    while($row2 = $result2->fetch_assoc()) 
				    		{
				    			if($row2['pa']==0)
				    			{ ?>

				    				<option><?php echo $row2['name']?></option>
				    				<?php
				    			}
				    		}
				    	}

		        		?>
          			</select>
				</div>
				<br><br><br>
				<div class="col-sm-12">
					
					<button type="submit" class="btn btn-default" name="submit" style="width: 182px;margin-left: 68	px;">Submit</button>
				</div>
        </form>
				<br><br><br>
		</div>
	</div>
</div>

