<?php
include 'function1.php';
if(isset($_GET['reg']))
{
$reg1=$_GET['reg'];
}

if(isset($_POST['submit']))
{
	$r1= $_POST['r1'];
	$r2= $_POST['r2'];
	$r3= $_POST['r3'];
	$r4= $_POST['r4'];
	$total=$r1+$r2+$r3+$r4;
	$r6= $_POST['r6'];

	$sq1="UPDATE marks SET a='$r1',b='$r2',c='$r3',d='$r4',review2='$total',remark2='$r6' WHERE reg='$reg1'";
    $result1=$db->query($sq1);

    echo "<script>alert('Successfully Updated');window.location.href='http://localhost/VIT_Capstone/marks_enter_review_select.php'</script>";


	
}
?>