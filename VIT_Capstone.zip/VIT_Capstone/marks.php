<?php
include 'function1.php';
if(isset($_GET['reg']))
{
$reg1=$_GET['reg'];
}

if(isset($_POST['submit']))
{
	$r1= $_POST['r1'];
	$r2= $_POST['r2'];

	$sq1="UPDATE marks SET review1='$r1',remark1='$r2' WHERE reg='$reg1'";
    $result1=$db->query($sq1);

    echo "<script>alert('Successfully Updated');window.location.href='http://localhost/VIT_Capstone/marks_enter_review_select.php'</script>";


	
}
?>