<?php

     
      if(isset($_POST['submit']))
      {  
      	 
		    
		    $tb_name=$_SESSION['x'];
		    $sq_test = "SELECT f_name FROM $tb_name WHERE id = '".$_SESSION['id']."' ";
		    $result = $db-> query($sq_test);
		    $row = $result->fetch_assoc();
		    $fac_tb=$row['f_name'];
		    $fac_tb_allo=$row['stud_alloted'];
		    $fac_tb_left=$row['stud_left'];
		    $fac_tb=strtolower($fac_tb);
			$fac_tb=str_replace(' ','',$fac_tb);
      		$sq="SELECT count FROM stud_login WHERE reg='".$_SESSION['reg']."'";
	      	$result = $db->query($sq);
	      	$row = $result->fetch_assoc();
	 		if($row['count']==0)
	 		{
	 			
	 			$sql="INSERT INTO $fac_tb (stud1,stud2,stud3,title) VALUES ('".$_POST['s1']."','".$_POST['s2']."','".$_POST['s3']."','".$_POST['title']."')";
			    if($db->query($sql) === TRUE)
			    {
			      echo "<script> alert('You have Successfully registered'); </script>";
			      $sql="UPDATE stud_login SET count='1' WHERE reg='".$_SESSION['reg']."'";
			   	  $result = $db->query($sql);
			   	  echo "<script>alert($tb_name)</script>";
			   	  echo "<script>alert($_SESSION['id'])</script>";
			   	  $fac_tb_allo=$fac_tb_allo+1;
			   	  $sql1="UPDATE $tb_name SET stud_alloted='$fac_tb_allo' WHERE id ='".$_SESSION['id']."'";
			   	  $result1= $db->query($sql1);
			    }
	 		}
	 		else
	 		{
	 			echo "<script> alert('You have already registered'); </script>";
	 		}

      		


	    
	   }

	?>