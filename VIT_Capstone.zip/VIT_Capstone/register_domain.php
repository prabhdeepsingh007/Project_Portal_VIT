<?php
include 'function.php';
if(isset($_GET['id']))
{
$_SESSION['id']=$_GET['id'];
}
if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/stud_login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>Welcome Student</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
		.sidepanel  {
  width: 0;
  position: fixed;
  z-index: 1;
  height: 320px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row" style="background-color: black; z-index: 999;">
			<div class="col-sm-2">
				<button class="openbtn" onclick="openNav()">☰</button>
				<div id="mySidepanel" class="sidepanel">
	  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
					<a href="stud_domain.php" style="margin-top: 30px;">Domain</a>
					<a href="project_upload.php">Project Upload</a>
					<a href="project_details.php">Project Details</a>
					<a href="reset_password.php">Reset Password</a>
				</div>

				<script>
				function openNav() {
				  document.getElementById("mySidepanel").style.width = "200px";
				}

				function closeNav() {
				  document.getElementById("mySidepanel").style.width = "0";
				}
				</script> 
			</div>
			<div class="col-sm-8">
				<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['reg']; ?></h1>
			</div>
			<div class="col-sm-2">
				<div style="float: right;">
					<form method="post">
						<input type="submit" name="logout" value="logout" style="margin: 20px;">
					</form>			
				</div>
			</div>
		</div>
	</div>
<br><br>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-2">
				
			</div>
			<div class="col-sm-8">
				<form class="form-horizontal" method="POST" action="register_domain.php">
    				<div class="form-group">
      					<div class="col-sm-12">
                 			<label>Title Of the Project</label>
                 			<textarea class="form-control custom_form_field" rows="5" col="50" name="title"
                  			placeholder="Enter the Title"></textarea>
             			</div>
    				</div>

    				<div class="form-group">    
    					<div class="col-sm-12">
                  			<label>Student 1</label>
                    		<input type="text" class="form-control custom_form_field" name="s1" placeholder="Registration Number" id="name">
              			</div>
    				</div>

    				<div class="form-group">    
    					<div class="col-sm-12">
                  			<label>Student 2</label>
                    		<input type="text" class="form-control custom_form_field" name="s2" placeholder="Registration Number" id="name">
              			</div>
    				</div>

    				<div class="form-group">    
    					<div class="col-sm-12">
                  			<label>Student 3</label>
                    		<input type="text" class="form-control custom_form_field" name="s3" placeholder="Registration Number" id="name">
              			</div>
    				</div>	    
      					<div class="col-sm-3">
        					<button type="submit" class="btn btn-default" name="submit" style="width:100%;">Submit</button>
      					</div>

    				
  				</form>
			</div>
			<div class="col-sm-2">
				
			</div>
		</div>
	</div>
	
<?php

     
      if(isset($_POST['submit']))
      {  
      	 
		    $stud2=$_POST['s2'];
		    $stud3=$_POST['s3'];
		    $tb_name=$_SESSION['x'];
		    $sq_test = "SELECT f_name FROM $tb_name WHERE id = '".$_SESSION['id']."' ";
		    $result = $db-> query($sq_test);
		    $row = $result->fetch_assoc();
		    $fac_tb=$row['f_name'];

		 //    $fac_tb=strtolower($fac_tb);
			// $fac_tb=str_replace(' ','',$fac_tb);
			
      		$sq="SELECT count FROM stud_login WHERE reg='".$_SESSION['reg']."'";
	      	$result = $db->query($sq);
	      	$row = $result->fetch_assoc();
	 		if($row['count']==0)
	 		{
	 			
	 			$sql="INSERT INTO $fac_tb (stud1,stud2,stud3,title) VALUES ('".$_POST['s1']."','".$_POST['s2']."','".$_POST['s3']."','".$_POST['title']."')";
			    if($db->query($sql) === TRUE)
			    {
			      echo "<script> alert('You have Successfully registered'); </script>";
			      $sql="UPDATE stud_login SET count='1',f_name='$fac_tb',domain='$tb_name' WHERE reg='".$_POST['s1']."'";
			   	  $result = $db->query($sql);

			   	  $sql2="UPDATE stud_login SET count='1',f_name='$fac_tb',domain='$tb_name' WHERE reg='$stud2'";
			   	  $result2 = $db->query($sql2);

			   	  $sql3="UPDATE stud_login SET count='1',f_name='$fac_tb',domain='$tb_name' WHERE reg='$stud3'";
			   	  $result3 = $db->query($sql3);
			   	  
			   	  $sql1="UPDATE $tb_name SET stud_alloted=stud_alloted+1,stud_left=stud_left-1 WHERE id ='".$_SESSION['id']."'";
			   	  $result1= $db->query($sql1);

			   	  

			    }
	 		}
	 		else
	 		{
	 			echo "<script> alert('You have already registered'); </script>";
	 		}

      		


	    
	   }

	?>
	

</body>
</html>