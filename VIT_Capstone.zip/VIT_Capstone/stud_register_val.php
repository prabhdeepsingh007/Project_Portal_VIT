<?php
include 'function.php';
include 'database.php';


if(isset($_POST['register']) /*&& preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST['password'])*/)
{
	
	if(empty($_POST["name"]))
		echo "Name is required";
	else
	{
		$name=$_POST["name"];
	}

	if(empty($_POST["reg"]))
		echo "Registration Number is required";
	else
	{
		$fname=$_POST["reg"];
	}

	if(empty($_POST["password"]))
		echo "Password";
	else
		$lname=$_POST["password"];

	if(empty($_POST["dob"]))
		echo "Date of Birth";
	else
		$username=$_POST["dob"];

	if(empty($_POST["number"]))
		echo "Contact number is required";
	else
		$password=$_POST["number"];

	if(empty($_POST["email"]))
		echo "Email is reguired";
	else
		$confirmpassword=$_POST["email"];

	


 	$sql = "INSERT INTO stud_login(name,reg,password,dob,num,email) VALUES ('$name','$fname','$lname','$username','$password','$confirmpassword')";
 	
 	if($db->query($sql) === TRUE)
	{ 	 
		echo "<script> alert('Registered');
    window.location.href='http://localhost/VIT_Capstone/register_student.php';
    </script>";
    
	}
	else
	{
	    echo "Error: " . $sql . "<br>" . $db->error;
	}

	$sql1 = "INSERT INTO marks(reg) VALUES ('$fname')";
 	
 	if($db->query($sql1) === TRUE)
	{ 	 
		echo "<script> alert('Registered');
    window.location.href='http://localhost/VIT_Capstone/register_student.php';
    </script>";
    
	}
	else
	{
	    echo "Error: " . $sql . "<br>" . $db->error;
	}

	$sql2 = "INSERT INTO upload(reg) VALUES ('$fname')";
 	
 	if($db->query($sql2) === TRUE)
	{ 	 
		echo "<script> alert('Registered');
    window.location.href='http://localhost/VIT_Capstone/register_student.php';
    </script>";
    
	}
	else
	{
	    echo "Error: " . $sql . "<br>" . $db->error;
	}
}
