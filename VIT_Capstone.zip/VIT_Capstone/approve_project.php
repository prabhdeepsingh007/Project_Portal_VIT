<?php
include 'function1.php';
include 'database.php';
if(isset($_GET['id']))
{
$_SESSION['id']=$_GET['id'];
}
$sq_test = "SELECT name FROM faculty_login WHERE fac_id = '".$_SESSION['fid']."' ";
$result = $db-> query($sq_test);
$row = $result->fetch_assoc();
$fac_tb=$row['name'];
$fac_tb=strtolower($fac_tb);
$fac_tb=str_replace(' ','',$fac_tb);

$sq1="UPDATE $fac_tb SET status='Approved' WHERE id='".$_SESSION['id']."'";
$result1=$db->query($sq1);

echo "<script>alert('Project Approved');
window.location.href='http://localhost/VIT_Capstone/project_approval.php'</script>";



?>