<?php
include 'function.php';
$sq_test = "SELECT f_name FROM stud_login WHERE reg = '".$_SESSION['reg']."' ";
$result = $db-> query($sq_test);
$row = $result->fetch_assoc();
$teacher=$row['f_name'];

$sql = "SELECT stud1,stud2,stud3 FROM $teacher WHERE stud1 = '".$_SESSION['reg']."' OR stud2 = '".$_SESSION['reg']."' OR stud3 = '".$_SESSION['reg']."' ";
$result1 = $db-> query($sql);
$row1 = $result1->fetch_assoc();
$reg1= $row1['stud1'];

$reg2=$row1['stud2'];

$reg3=$row1['stud3'];

$sq="SELECT domain FROM stud_login WHERE reg='".$_SESSION['reg']."'";
$result = $db->query($sq);
$row = $result->fetch_assoc();
$x=$row['domain'];

$sq1="UPDATE stud_login SET count='0',domain=' ',f_name=' ' WHERE reg='$reg1'";
$result1=$db->query($sq1);
$sq2="UPDATE stud_login SET count='0',domain=' ',f_name=' ' WHERE reg='$reg2'";
$result2=$db->query($sq2);
$sq3="UPDATE stud_login SET count='0',domain=' ',f_name=' ' WHERE reg='$reg3'";
$result3=$db->query($sq3);





$sql5="UPDATE $x SET stud_alloted=stud_alloted-1,stud_left=stud_left+1 WHERE f_name='$teacher' ";
$result5= $db->query($sql5);

$sq="DELETE  FROM $teacher WHERE stud1 = '".$_SESSION['reg']."' OR stud2 = '".$_SESSION['reg']."' OR stud3 = '".$_SESSION['reg']."' ";
$del= $db-> query($sq);

echo "<script>alert('Successfully Deleted');window.location.href='http://localhost/VIT_Capstone/project_details.php'</script>";



?>