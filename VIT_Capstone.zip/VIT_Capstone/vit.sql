-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2019 at 09:50 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vit`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_schedule`
--

CREATE TABLE `data_schedule` (
  `id` int(11) NOT NULL,
  `faculty1` varchar(100) NOT NULL,
  `faculty2` varchar(100) NOT NULL,
  `faculty3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_schedule`
--

INSERT INTO `data_schedule` (`id`, `faculty1`, `faculty2`, `faculty3`) VALUES
(2, 'Rajkumar K', 'aa', 'bb'),
(3, 'Rajkumar K', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `fac_id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `pa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`, `fac_id`, `password`, `pa`) VALUES
(1, 'aa', '12578', 'password123', '1'),
(2, 'bb', '12568', 'password123', '0'),
(3, 'cc', '12378', 'password123', '0'),
(4, 'dd', '13578', 'password123', '0');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_login`
--

CREATE TABLE `faculty_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `fac_id` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `pa` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_login`
--

INSERT INTO `faculty_login` (`id`, `name`, `fac_id`, `password`, `domain`, `pa`) VALUES
(1, 'Rajkumar K', 14321, 'password123', 'imageprocessing', 1),
(2, 'Natrajan P', 15897, 'password123', 'imageprocessing', 0),
(3, 'a', 15678, 'password123', '', 1),
(4, 'b', 12654, 'password123', '', 1),
(5, 'c', 12547, 'password123', '', 0),
(6, 'd', 12547, 'password123', '', 0),
(7, 'e', 12847, 'password123', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hodlogin`
--

CREATE TABLE `hodlogin` (
  `id` int(100) NOT NULL,
  `hodid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hodlogin`
--

INSERT INTO `hodlogin` (`id`, `hodid`, `password`) VALUES
(1, '12345', 'password123');

-- --------------------------------------------------------

--
-- Table structure for table `imageprocessing`
--

CREATE TABLE `imageprocessing` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imageprocessing`
--

INSERT INTO `imageprocessing` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '14321', 'rajkumark', '1', '4', 'Rajkumar K'),
(2, '12345', 'natrajanp', '0', '5', 'Natrajan P');

-- --------------------------------------------------------

--
-- Table structure for table `machinelearning`
--

CREATE TABLE `machinelearning` (
  `id` int(100) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machinelearning`
--

INSERT INTO `machinelearning` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`) VALUES
(1, '25491', 'Vijayasherly', '5', '0');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `review1` varchar(100) NOT NULL,
  `review2` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `b` varchar(100) NOT NULL,
  `c` varchar(100) NOT NULL,
  `d` varchar(100) NOT NULL,
  `review3` varchar(100) NOT NULL,
  `a1` varchar(100) NOT NULL,
  `b1` varchar(100) NOT NULL,
  `c1` varchar(100) NOT NULL,
  `d1` varchar(100) NOT NULL,
  `remark1` varchar(100) NOT NULL,
  `remark2` varchar(100) NOT NULL,
  `remark3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rajkumark`
--

CREATE TABLE `rajkumark` (
  `id` int(100) NOT NULL,
  `stud1` varchar(100) NOT NULL,
  `stud2` varchar(100) NOT NULL,
  `stud3` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rajkumark`
--

INSERT INTO `rajkumark` (`id`, `stud1`, `stud2`, `stud3`, `status`, `title`) VALUES
(2, '16BCE0611', '16BCE0592', '16BCE2280', 'Approved', 'Skin Cancer');

-- --------------------------------------------------------

--
-- Table structure for table `review2`
--

CREATE TABLE `review2` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `b` varchar(100) NOT NULL,
  `c` varchar(100) NOT NULL,
  `d` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stud_login`
--

CREATE TABLE `stud_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `count` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `domain` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_login`
--

INSERT INTO `stud_login` (`id`, `name`, `reg`, `password`, `count`, `f_name`, `domain`) VALUES
(1, 'Kunal Keshri', '16BCE2280', 'password123', '1', 'rajkumark', 'imageprocessing'),
(2, 'Akash Goyal', '16BCE0592', 'password124', '1', 'rajkumark', 'imageprocessing'),
(3, 'Prabhdeep', '16BCE0611', 'password10', '1', 'rajkumark', 'imageprocessing');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `doc1` mediumblob NOT NULL,
  `name1` varchar(500) NOT NULL,
  `type1` varchar(100) NOT NULL,
  `doc2` mediumblob NOT NULL,
  `name2` varchar(500) NOT NULL,
  `type2` varchar(100) NOT NULL,
  `doc3` mediumblob NOT NULL,
  `name3` varchar(500) NOT NULL,
  `type3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `upload1`
--

CREATE TABLE `upload1` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `doc1` mediumblob NOT NULL,
  `name1` varchar(500) NOT NULL,
  `type1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_schedule`
--
ALTER TABLE `data_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_login`
--
ALTER TABLE `faculty_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hodlogin`
--
ALTER TABLE `hodlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imageprocessing`
--
ALTER TABLE `imageprocessing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machinelearning`
--
ALTER TABLE `machinelearning`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rajkumark`
--
ALTER TABLE `rajkumark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review2`
--
ALTER TABLE `review2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_login`
--
ALTER TABLE `stud_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload1`
--
ALTER TABLE `upload1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_schedule`
--
ALTER TABLE `data_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faculty_login`
--
ALTER TABLE `faculty_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hodlogin`
--
ALTER TABLE `hodlogin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `imageprocessing`
--
ALTER TABLE `imageprocessing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `machinelearning`
--
ALTER TABLE `machinelearning`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rajkumark`
--
ALTER TABLE `rajkumark`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `review2`
--
ALTER TABLE `review2`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stud_login`
--
ALTER TABLE `stud_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `upload1`
--
ALTER TABLE `upload1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
