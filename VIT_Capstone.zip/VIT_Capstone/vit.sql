-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2019 at 03:13 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vit`
--

-- --------------------------------------------------------

--
-- Table structure for table `anandm`
--

CREATE TABLE `anandm` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `anuradhad`
--

CREATE TABLE `anuradhad` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `arunkumars`
--

CREATE TABLE `arunkumars` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chandramohan`
--

CREATE TABLE `chandramohan` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `computationaldesign`
--

CREATE TABLE `computationaldesign` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computationaldesign`
--

INSERT INTO `computationaldesign` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'shanthik', '0', '5', 'Shanthi K');

-- --------------------------------------------------------

--
-- Table structure for table `cryptography`
--

CREATE TABLE `cryptography` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cryptography`
--

INSERT INTO `cryptography` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'anandm', '0', '5', 'Anand M');

-- --------------------------------------------------------

--
-- Table structure for table `databasesystems`
--

CREATE TABLE `databasesystems` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `databasesystems`
--

INSERT INTO `databasesystems` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'ramanis', '0', '5', 'Ramani S');

-- --------------------------------------------------------

--
-- Table structure for table `datastructures`
--

CREATE TABLE `datastructures` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datastructures`
--

INSERT INTO `datastructures` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'anuradhad', '0', '5', 'Anuradha D');

-- --------------------------------------------------------

--
-- Table structure for table `data_schedule`
--

CREATE TABLE `data_schedule` (
  `id` int(11) NOT NULL,
  `faculty1` varchar(100) NOT NULL,
  `faculty2` varchar(100) NOT NULL,
  `faculty3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_schedule`
--

INSERT INTO `data_schedule` (`id`, `faculty1`, `faculty2`, `faculty3`) VALUES
(2, 'Rajkumar K', 'aa', 'bb'),
(3, 'Rajkumar K', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `digitallogicanddesign`
--

CREATE TABLE `digitallogicanddesign` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `digitallogicanddesign`
--

INSERT INTO `digitallogicanddesign` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'yokeshbabu', '0', '5', 'Yokesh Babu');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_login`
--

CREATE TABLE `faculty_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `fac_id` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `pa` int(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_login`
--

INSERT INTO `faculty_login` (`id`, `name`, `fac_id`, `password`, `domain`, `pa`, `stud_left`, `stud_alloted`, `f_name`) VALUES
(1, 'Rajkumar K', 14321, 'password123', ' ', 1, '5', '0', 'rajkumark'),
(2, 'Natrajan P', 15897, 'password123', '', 0, '5', '0', 'natrajanp'),
(8, 'Vijaysherly V', 14325, 'password123', '', 0, '5', '0', 'vijaysherlyv'),
(9, 'anandm', 12456, 'password123', '', 0, '5', '0', 'Anand M'),
(11, 'anuradhad', 12455, 'password123', '', 0, '5', '0', 'Anuradha D'),
(12, 'arunkumars', 12457, 'password123', '', 0, '5', '0', 'Arunkumar S'),
(13, 'chandramohan', 12458, 'password123', '', 0, '5', '0', 'Chandramohan'),
(14, 'nalinin', 12367, 'password123', '', 0, '5', '0', 'Nalini N'),
(16, 'ramanis', 13452, 'password123', '', 0, '5', '0', 'Ramani S');

-- --------------------------------------------------------

--
-- Table structure for table `graphics`
--

CREATE TABLE `graphics` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphics`
--

INSERT INTO `graphics` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'natrajanp', '0', '5', 'Natrajan P');

-- --------------------------------------------------------

--
-- Table structure for table `hodlogin`
--

CREATE TABLE `hodlogin` (
  `id` int(100) NOT NULL,
  `hodid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hodlogin`
--

INSERT INTO `hodlogin` (`id`, `hodid`, `password`) VALUES
(1, '12345', 'password123');

-- --------------------------------------------------------

--
-- Table structure for table `imageprocessing`
--

CREATE TABLE `imageprocessing` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imageprocessing`
--

INSERT INTO `imageprocessing` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(2, '12345', 'natrajanp', '0', '5', 'Natrajan P');

-- --------------------------------------------------------

--
-- Table structure for table `iot`
--

CREATE TABLE `iot` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iot`
--

INSERT INTO `iot` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'arunkumart', '0', '5', 'Arunkumar T');

-- --------------------------------------------------------

--
-- Table structure for table `machinelearning`
--

CREATE TABLE `machinelearning` (
  `id` int(100) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `machinelearning`
--

INSERT INTO `machinelearning` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '25491', 'vijayasherly', '0', '5', 'Vijayasherly');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `review1` varchar(100) NOT NULL,
  `review2` varchar(100) NOT NULL,
  `a` varchar(100) NOT NULL,
  `b` varchar(100) NOT NULL,
  `c` varchar(100) NOT NULL,
  `d` varchar(100) NOT NULL,
  `review3` varchar(100) NOT NULL,
  `a1` varchar(100) NOT NULL,
  `b1` varchar(100) NOT NULL,
  `c1` varchar(100) NOT NULL,
  `d1` varchar(100) NOT NULL,
  `remark1` varchar(100) NOT NULL,
  `remark2` varchar(100) NOT NULL,
  `remark3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `reg`, `review1`, `review2`, `a`, `b`, `c`, `d`, `review3`, `a1`, `b1`, `c1`, `d1`, `remark1`, `remark2`, `remark3`) VALUES
(6, '16BCE0611', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, '16BCE2280', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, '16BCE0592', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `mohank`
--

CREATE TABLE `mohank` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nalinin`
--

CREATE TABLE `nalinin` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nalinin`
--

INSERT INTO `nalinin` (`id`, `stud1`, `stud2`, `stud3`, `status`, `title`) VALUES
(1, '16BCE0611', '', '', NULL, 'Programming');

-- --------------------------------------------------------

--
-- Table structure for table `nareshs`
--

CREATE TABLE `nareshs` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `natrajanp`
--

CREATE TABLE `natrajanp` (
  `id` int(100) NOT NULL,
  `stud1` varchar(100) NOT NULL,
  `stud2` varchar(100) NOT NULL,
  `stud3` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `operatingsystems`
--

CREATE TABLE `operatingsystems` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operatingsystems`
--

INSERT INTO `operatingsystems` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'selvakumar', '0', '5', 'Selvakumar');

-- --------------------------------------------------------

--
-- Table structure for table `programminglanguages`
--

CREATE TABLE `programminglanguages` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `programminglanguages`
--

INSERT INTO `programminglanguages` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(0, '11111', 'mohank', '0', '5', 'Mohan K');

-- --------------------------------------------------------

--
-- Table structure for table `rajkumark`
--

CREATE TABLE `rajkumark` (
  `id` int(100) NOT NULL,
  `stud1` varchar(100) NOT NULL,
  `stud2` varchar(100) NOT NULL,
  `stud3` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `title` varchar(500) NOT NULL,
  `domain` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ramanis`
--

CREATE TABLE `ramanis` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `santhih`
--

CREATE TABLE `santhih` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `selvakumar`
--

CREATE TABLE `selvakumar` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shanthik`
--

CREATE TABLE `shanthik` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `softcomputing`
--

CREATE TABLE `softcomputing` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `softcomputing`
--

INSERT INTO `softcomputing` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'nareshs', '0', '5', 'Naresh S');

-- --------------------------------------------------------

--
-- Table structure for table `softwareengineering`
--

CREATE TABLE `softwareengineering` (
  `id` int(11) NOT NULL,
  `f_id` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `softwareengineering`
--

INSERT INTO `softwareengineering` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'arunkumars', '0', '5', 'Arunkumar S');

-- --------------------------------------------------------

--
-- Table structure for table `stud_login`
--

CREATE TABLE `stud_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `count` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `num` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `upload` varchar(100) NOT NULL,
  `upload1` varchar(100) NOT NULL,
  `upload2` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_login`
--

INSERT INTO `stud_login` (`id`, `name`, `reg`, `password`, `count`, `f_name`, `domain`, `dob`, `num`, `email`, `upload`, `upload1`, `upload2`) VALUES
(10, 'Prabhdeep', '16BCE0611', 'password10', '0', ' ', ' ', '1998-11-18', '9998876543', 'p@gmail.com', '', '', ''),
(11, 'Kunal', '16BCE2280', 'password123', '0', ' ', ' ', '1997-01-01', '9089765432', 'k@gmail.com', '', '', ''),
(12, 'Akash', '16BCE0592', 'password123', '', '', '', '1998-01-01', '9998765431', 'a@gmail.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `doc1` mediumblob NOT NULL,
  `name1` varchar(500) NOT NULL,
  `type1` varchar(100) NOT NULL,
  `doc2` mediumblob NOT NULL,
  `name2` varchar(500) NOT NULL,
  `type2` varchar(100) NOT NULL,
  `doc3` mediumblob NOT NULL,
  `name3` varchar(500) NOT NULL,
  `type3` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id`, `reg`, `doc1`, `name1`, `type1`, `doc2`, `name2`, `type2`, `doc3`, `name3`, `type3`) VALUES
(4, '16BCE0611', '', '', '', '', '', '', '', '', ''),
(5, '16BCE2280', '', '', '', '', '', '', '', '', ''),
(6, '16BCE0592', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `websystems`
--

CREATE TABLE `websystems` (
  `id` int(11) NOT NULL,
  `f_id` int(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `stud_alloted` varchar(100) NOT NULL,
  `stud_left` varchar(100) NOT NULL,
  `f_name1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `websystems`
--

INSERT INTO `websystems` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, 12345, 'nalinin', '1', '4', 'Nalini N');

-- --------------------------------------------------------

--
-- Table structure for table `wirelesscommucationandnetworks`
--

CREATE TABLE `wirelesscommucationandnetworks` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wirelesscommucationandnetworks`
--

INSERT INTO `wirelesscommucationandnetworks` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'santhih ', '0', '5', 'Santhi H ');

-- --------------------------------------------------------

--
-- Table structure for table `wirelesssecurity`
--

CREATE TABLE `wirelesssecurity` (
  `id` int(11) NOT NULL,
  `f_id` varchar(255) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `stud_alloted` varchar(255) DEFAULT NULL,
  `stud_left` varchar(255) DEFAULT NULL,
  `f_name1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wirelesssecurity`
--

INSERT INTO `wirelesssecurity` (`id`, `f_id`, `f_name`, `stud_alloted`, `stud_left`, `f_name1`) VALUES
(1, '12345', 'chandramohan', '0', '5', 'Chandramohan');

-- --------------------------------------------------------

--
-- Table structure for table `yokeshbabu`
--

CREATE TABLE `yokeshbabu` (
  `id` int(11) NOT NULL,
  `stud1` varchar(255) DEFAULT NULL,
  `stud2` varchar(255) DEFAULT NULL,
  `stud3` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anandm`
--
ALTER TABLE `anandm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `anuradhad`
--
ALTER TABLE `anuradhad`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arunkumars`
--
ALTER TABLE `arunkumars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chandramohan`
--
ALTER TABLE `chandramohan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `computationaldesign`
--
ALTER TABLE `computationaldesign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cryptography`
--
ALTER TABLE `cryptography`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `databasesystems`
--
ALTER TABLE `databasesystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datastructures`
--
ALTER TABLE `datastructures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_schedule`
--
ALTER TABLE `data_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `digitallogicanddesign`
--
ALTER TABLE `digitallogicanddesign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_login`
--
ALTER TABLE `faculty_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `graphics`
--
ALTER TABLE `graphics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hodlogin`
--
ALTER TABLE `hodlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imageprocessing`
--
ALTER TABLE `imageprocessing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iot`
--
ALTER TABLE `iot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machinelearning`
--
ALTER TABLE `machinelearning`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mohank`
--
ALTER TABLE `mohank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nalinin`
--
ALTER TABLE `nalinin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nareshs`
--
ALTER TABLE `nareshs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `natrajanp`
--
ALTER TABLE `natrajanp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operatingsystems`
--
ALTER TABLE `operatingsystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programminglanguages`
--
ALTER TABLE `programminglanguages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rajkumark`
--
ALTER TABLE `rajkumark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ramanis`
--
ALTER TABLE `ramanis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `santhih`
--
ALTER TABLE `santhih`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selvakumar`
--
ALTER TABLE `selvakumar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shanthik`
--
ALTER TABLE `shanthik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `softcomputing`
--
ALTER TABLE `softcomputing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `softwareengineering`
--
ALTER TABLE `softwareengineering`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_login`
--
ALTER TABLE `stud_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `websystems`
--
ALTER TABLE `websystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wirelesscommucationandnetworks`
--
ALTER TABLE `wirelesscommucationandnetworks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wirelesssecurity`
--
ALTER TABLE `wirelesssecurity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `yokeshbabu`
--
ALTER TABLE `yokeshbabu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anandm`
--
ALTER TABLE `anandm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `anuradhad`
--
ALTER TABLE `anuradhad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `arunkumars`
--
ALTER TABLE `arunkumars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chandramohan`
--
ALTER TABLE `chandramohan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `computationaldesign`
--
ALTER TABLE `computationaldesign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cryptography`
--
ALTER TABLE `cryptography`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `databasesystems`
--
ALTER TABLE `databasesystems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `datastructures`
--
ALTER TABLE `datastructures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_schedule`
--
ALTER TABLE `data_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `digitallogicanddesign`
--
ALTER TABLE `digitallogicanddesign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculty_login`
--
ALTER TABLE `faculty_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `graphics`
--
ALTER TABLE `graphics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hodlogin`
--
ALTER TABLE `hodlogin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `imageprocessing`
--
ALTER TABLE `imageprocessing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `iot`
--
ALTER TABLE `iot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `machinelearning`
--
ALTER TABLE `machinelearning`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mohank`
--
ALTER TABLE `mohank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nalinin`
--
ALTER TABLE `nalinin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `nareshs`
--
ALTER TABLE `nareshs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `natrajanp`
--
ALTER TABLE `natrajanp`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `operatingsystems`
--
ALTER TABLE `operatingsystems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rajkumark`
--
ALTER TABLE `rajkumark`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ramanis`
--
ALTER TABLE `ramanis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `santhih`
--
ALTER TABLE `santhih`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `selvakumar`
--
ALTER TABLE `selvakumar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shanthik`
--
ALTER TABLE `shanthik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `softcomputing`
--
ALTER TABLE `softcomputing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `softwareengineering`
--
ALTER TABLE `softwareengineering`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stud_login`
--
ALTER TABLE `stud_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `websystems`
--
ALTER TABLE `websystems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wirelesscommucationandnetworks`
--
ALTER TABLE `wirelesscommucationandnetworks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wirelesssecurity`
--
ALTER TABLE `wirelesssecurity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `yokeshbabu`
--
ALTER TABLE `yokeshbabu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
