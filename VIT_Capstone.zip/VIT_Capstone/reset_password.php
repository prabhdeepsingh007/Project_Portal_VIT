<?php
include 'function.php';

if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/stud_login.php");
}


?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	<title>Welcome Student</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
	<style type="text/css">
		.sidepanel  {
  width: 0;
  position: fixed;
  z-index: 1;
  height: 320px;
  top: 66px;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidepanel a:hover {
  color: #f1f1f1;
}

.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.openbtn {
  font-size: 20px;
  cursor: pointer;
  background-color: #111;
  color: white;
  padding: 10px 15px;
  border: none;
}

.openbtn:hover {
  background-color:#444;
}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="row" style="background-color: black; z-index: 999;">
		<div class="col-sm-2">
			<button class="openbtn" onclick="openNav()">☰</button>
			<div id="mySidepanel" class="sidepanel">
  				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
				<a href="stud_domain.php" style="margin-top: 30px;">Domain</a>
				<a href="project_upload.php">Project Upload</a>
				<a href="project_details.php">Project Details</a>
				<a href="reset_password.php">Reset Password</a>
			</div>


			<script>
			function openNav() {
			  document.getElementById("mySidepanel").style.width = "200px";
			}

			function closeNav() {
			  document.getElementById("mySidepanel").style.width = "0";
			}
			</script> 
		</div>
		<div class="col-sm-8">
			<h2  style="color: white; text-align: center;">Welcome <?php echo $_SESSION['reg']; ?></h1>
		</div>
		<div class="col-sm-2">
			<div style="float: right;">
				<form method="post">
					<input type="submit" name="logout" value="logout" style="margin: 20px;">
				</form>			
			</div>
		</div>
	</div>
</div>

<br>
<div class="container-fluid">
		<div class="row">
			<div class="col-sm-2">
				
			</div>
			<div class="col-sm-8">
				<form class="form-horizontal" method="POST" action="reset_password.php">
    				<div class="form-group">    
    					<div class="col-sm-12">
                  			<label>Enter New Password</label>
                    		<input type="password" class="form-control custom_form_field" name="p1" placeholder="New Password" id="name">
              			</div>
    				</div>

    				<div class="form-group">    
    					<div class="col-sm-12">
                  			<label>Confirm New Password</label>
                    		<input type="password" class="form-control custom_form_field" name="cnf" placeholder="Confirm New Password" id="name">
              			</div>
    				</div>
    
      				<div class="col-sm-3">
        				<button type="submit" class="btn btn-default" name="submit" style="width:100%;">Submit</button>
      				</div>

    				
  				</form>
			</div>
			<div class="col-sm-2">
				
			</div>
		</div>
		<?php
		if(isset($_POST['submit']))
		{
			if($_POST['p1']==$_POST['cnf'])
			{
				$sq1="UPDATE stud_login SET password='".$_POST['cnf']."' WHERE reg='".$_SESSION['reg']."' ";
				$result1=$db->query($sq1);
				echo "<script>alert('Password Updated Successfully');
				window.location.href='http://localhost/VIT_Capstone/reset_password.php'</script>";
			}
			else
			{
				echo "<script>alert('New Password And Confirm Password do not match');
				window.location.href='http://localhost/VIT_Capstone/reset_password.php'</script>";
			}
		}

		?>
	</div>
</body>
</html>