<?php
include 'database.php';
session_start();

function base_url()
{
	return ("http://" . $_SERVER['SERVER_NAME'] .'/VIT_Capstone'); //base url
}

function session_check()
{
	if (isset($_SESSION['login'])) 
	{
		if ($_SESSION['login']== true) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}


?>