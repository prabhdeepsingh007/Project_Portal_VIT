<?php
include 'function1.php';
include 'database.php';


if(isset($_POST['login']) /*&& preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST['password'])*/)
{
	$sql = "SELECT * FROM faculty_login WHERE fac_id = '".$_POST['fid']."' and password = '".$_POST['password']."'";

	$result = $db-> query($sql);
	if($result->num_rows > 0)
	{
		$_SESSION['fid'] = $_POST['fid'];
		$_SESSION['login'] = true;
		echo "<script> alert('Correct Credentials'); 
		window.location.href='http://localhost/VIT_Capstone/faculty_login.php';</script>"; exit;
	}
	else
	{
		echo "<script> alert('Incorrect Credentials') 
		window.location.href='http://localhost/VIT_Capstone/faculty_login.php';</script>"; exit;

	}
}



/*include 'function.php';


	if(isset($_POST['login']))
	{
		if($_POST['name']=='Prabhdeep' && $_POST['password']=='123456')
		{
			$_SESSION['username'] = $_POST['name'];
			$_SESSION['login'] = true;
			echo json_encode(array('type' => 'success','msg' => 'Login Successful'));exit;
		}
		else
		{
			echo json_encode(array('type' => 'failed','msg' => 'Invalid Credentials'));

		}
	}*/


?>
